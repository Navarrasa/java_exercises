package lista3;

import java.util.Scanner;

public class Atividade5 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);








    }
}
