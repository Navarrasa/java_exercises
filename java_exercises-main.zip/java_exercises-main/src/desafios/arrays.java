package desafio_dificil;

import java.util.Scanner;

public class arrays {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int quantidade = scanner.nextInt();



    }
}