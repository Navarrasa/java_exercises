package lacos;

public class lacoWhile {

    public static void main(String[] args) {

        int contador = 0;

        while (contador <= 20){
            System.out.println("Olá, o contador está em: "+contador);
            contador++;
        }

    }
}
