package lacos;

public class lacoWhile2 {

    public static void main(String[] args) {

        int contadorAtual = 0;
        int total = 0;


        while (contadorAtual <=10){

            total = total + contadorAtual;
            System.out.println(total);
            contadorAtual++;

        }

    }

}
