public class dados {

    public static void Main(String[] args){

        String nome = "Brini";
        int idade = 18;
        double altura = 1.82;
        double saldo = 1500.98284;
        double taxaDesconto = 0.15;
        int codigoProduto = 25;

        System.out.print("Olá ");
        System.out.print("");
    }

}

